let age = 0; // Armazena a idade
let message = "Digite sua idade para recomendação de filmes:"; // Mensagem inicial
let input, button; // Elementos de entrada

function setup() {
  createCanvas(400, 200); // Define o tamanho da tela

  // Caixa de entrada para idade
  input = createInput();
  input.position(20, 60);

  // Botão para confirmar a entrada
  button = createButton('Confirmar');
  button.position(input.x + input.width + 10, 60);
  button.mousePressed(recommendMovie); // Ação ao clicar no botão

  // Configuração de texto inicial
  textAlign(CENTER);
  textSize(16);
}

function draw() {
  background(220); // Fundo da tela

  // Exibe a mensagem no topo
  fill(0);
  text(message, width / 2, 30);
}

function recommendMovie() {
  // Captura o valor da idade
  age = int(input.value());

  // Verifica a faixa etária e atribui a recomendação correspondente
  if (age < 6) {
    message = 'Recomendado: "Ratatouille" ou "Bob Esponja"';
  } else if (age < 10) {
    message = 'Recomendado: "McQueen"';
  } else if (age < 12) {
    message = 'Recomendado: "Planeta dos Macacos"';
  } else if (age < 14) {
    message = 'Recomendado: "Liga da Justiça" ou "Batman"';
  } else if (age < 16) {
    message = 'Recomendado: "Velozes e Furiosos 6"';
  } else if (age < 18) {
    message = 'Recomendado: "Rambo"';
  } else {
    message = 'Recomendado: "Coringa" ou "It: A Coisa"';
  }

  // Limpa o campo de entrada
  input.value('');
}